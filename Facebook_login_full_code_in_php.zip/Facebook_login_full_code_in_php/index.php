<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once('Facebook/autoload.php');

 function facebook_login()
	{	
		$fb = new Facebook\Facebook([
		'app_id' => 'your app_id',
		'app_secret' => 'your secret id',
		'default_graph_version' => 'v2.11'
		]);
		$config['app_id']='534927106857885';  
		$helper = $fb->getRedirectLoginHelper(); 
if (isset($_GET['state'])) { $helper->getPersistentDataHandler()->set('state', $_GET['state']); } 				  
		try {  
		  $accessToken = $helper->getAccessToken();  
		} catch(Facebook\Exceptions\FacebookResponseException $e) {  
		  // When Graph returns an error  
		  echo 'Graph returned an error: ' . $e->getMessage();  
		  
		} catch(Facebook\Exceptions\FacebookSDKException $e) {  
		  // When validation fails or other local issues  
		  echo 'Facebook SDK returned an error: ' . $e->getMessage();  
		     
		}  

		if (! isset($accessToken)) {  
		  if ($helper->getError()) {  
			//header('HTTP/1.0 401 Unauthorized');  
			echo "Error: " . $helper->getError() . "\n";
			echo "Error Code: " . $helper->getErrorCode() . "\n";
			echo "Error Reason: " . $helper->getErrorReason() . "\n";
			echo "Error Description: " . $helper->getErrorDescription() . "\n";
			
		  } else {  
			//header('HTTP/1.0 400 Bad Request');  
			echo 'Bad request'; 
			
		  }  
		  exit;  
		}
				
		try {
		  // Returns a `Facebook\FacebookResponse` object
		  $response = $fb->get('/me?fields=id,name,email', $accessToken);
		} catch(Facebook\Exceptions\FacebookResponseException $e) {
		  echo 'Graph returned an error: ' . $e->getMessage();
		  
		} catch(Facebook\Exceptions\FacebookSDKException $e) {
		  echo 'Facebook SDK returned an error: ' . $e->getMessage();
		  
		}
	
			$user = $response->getGraphUser();
			$email=$user['email'];
			if(empty($email)) // check when user not checked the
			{
				echo $msg='Please provide your email for login with Facebook'; 					
			}
			$name=$user['name'];
			$fb_id=$user['id'];
                      return $user;
			
			
	}
$logout='';
$userdetails='';
if(isset($_GET['code'])  && $_GET['code']!="" )
{
   $userdetails=facebook_login();
   $fb_url = "";

}
else
{

$fb = new Facebook\Facebook([
        'app_id' => 'your app_id',
		'app_secret' => 'your secret id',
    'default_graph_version' => 'v2.11'
    ]);
    $helper = $fb->getRedirectLoginHelper();
    $permissions = ['email']; // optional   
    $fb_url = $helper->getLoginUrl( 'http://moderntutorial.com/facebook_login/index.php', $permissions);

}
   
?>

<!DOCTYPE HTML>
<html>
<head>
	<!-- Meta -->
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Facebook Login | Moderntutorial</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width">
	<link rel="icon" href="favicon.ico" type="image/x-icon">
	<!-- Load CSS -->
	<link href="style.css" rel="stylesheet" type="text/css" />
	<!-- Load Fonts -->
	<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=PT+Sans:regular,bold" type="text/css" />
	<!-- Load jQuery library -->
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
	<!-- Load custom js -->
	<script type="text/javascript" src="custom.js"></script>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-113483198-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-113483198-1');
</script>
</head>
<body>
<h1 style="text-align: center;">Facebook Login Using Php</h1>
	<div id="main">
  
		<!-- Main Title -->
		<div class="icon"></div>
		<h3 class="title" style="font-size: 24px;">Login With Facebook</h3>
<?php if($fb_url!=""){?>		
<a href="<?php echo $fb_url;?>"><img src="http://www.moderntutorial.com/facebook_login/image/facebook-login-300x144.png"/></a>
<?php }else{

if($userdetails!="")
{
   
  echo '<p style="color:green;font-size: 14px;">Successfully login with '.$userdetails['email'].'</p>';
}

}?>


	</div>

</body>
</html>